# DrugTax
Categorize small ligands according to chemical properties. Derive simple and explainable features. Only requires SMILEs as inputs.
